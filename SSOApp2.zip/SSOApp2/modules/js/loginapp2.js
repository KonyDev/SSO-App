//var StoreInKeyChainObject = new keychainFFI.StoreInKeyChain();
appKey="144f8491943f6a3ba60a93d4c470f28c";
appSecret="c4ed2f3caa22cb6cc5b4d8dd046333b2";
var  providerName = "testcust232";
serviceURL="http://mbaastest8.konylabs.net:9089/authService/100000002/appconfig";
username="";
password="";
KeychainValue="";
claimsToken="";
var StoreInKeyChainObject;
function appInit(){
	kony.print("\n*******in app init*******");
	if(kony.os.deviceInfo().name=="iPhone" || kony.os.deviceInfo().name=="iPhone Simulator"){
		//StoreInKeyChainObject = new keychainFFI.StoreInKeyChain();
	}
}

 /**
 * Name		:	Directlogin
 * Author	:	Kony
 * Purpose	:	This function is used to Login user directly by using sso token from keychain.
**/  
function Directlogin(){
     
	

	  	    kony.print("\n\n-----------in direct login function---------------\n");
	  	    if(kony.os.deviceInfo().name=="iPhone"||kony.os.deviceInfo().name=="iPhone Simulator"){
	  	    
	  	    }else if(kony.os.deviceInfo().name=="android"){
	  	    
	  	    }
			var inputParamTable={
						httpheaders:{
						    "X-Kony-App-Key":appKey,
						    "X-Kony-App-Secret":appSecret,
						    "Authorization":KeychainValue
			            	
			            	},
						postdata:""
					
		    };
		    try{
				var url="http://mbaastest8.konylabs.net:9089/authService/100000002/login?provider=testcust232&$exclude=provider_token";
			   	kony.print("\nurl-->"+url);
			   	kony.print("\n ipTable-->"+JSON.stringify(inputParamTable));
			   	kony.application.showLoadingScreen("sknLoading","Direct Login..",constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true,null);
			   	var connHandle = kony.net.invokeServiceAsync(
		                        url,inputParamTable,asyncCallback);
			}catch(err){
		    	kony.print("\nexeption in invoking service---\n"+JSON.stringify(err));
				alert("Error"+err);
		    }
    
function asyncCallback(status, result) 
	{
    	kony.print("\n------status------>"+status);
    	kony.print("\n result**********************"+JSON.stringify(result));
    	if(status==400 && result["httpresponse"]!=undefined)
    	{
    			if(result["httpresponse"]["responsecode"]==400){
    				kony.print("\nError in Directlogin:-\n"+ JSON.stringify(result));
    				
    				//frmLogin.show();
    				return;
    			}else if(result["httpresponse"]["responsecode"]==200){
    				kony.print("\n result:-"+JSON.stringify(result));
    				claimsToken=result.claims_token["value"];
    				kony.print("User profile is  :" + result.profile["firstname"]);
					kony.print("User profile is  :" + result.profile["lastname"]);
					frmProfile.lblUsername.text=result.profile.firstname+" "+result.profile.lastname;
					frmProfile.lblEmail.text=result.profile.firstname+"."+result.profile.lastname+"@gmail.com";
    				frmProfile.show();
    	}
    	else{
    	       //Defining basicConf parameter for alert
				var basicConf = {message: "your login session has expired. please login again to continue.",alertType: constants.
				ALERT_TYPE_INFO,alertTitle: "Session Expired ",yesLabel:"OK",
				noLabel: "", alertHandler: handle2};
				
				//Defining pspConf parameter for alert
				var pspConf = {};
				
				//Alert definition
				var infoAlert = kony.ui.Alert(basicConf,pspConf);
				function handle2(response)
				{
				  frmLogin.show();
				}
				
    	  
    	}
    	
    	kony.application.dismissLoadingScreen();
    	
    }
	}
    
    	
		   
   }
   

/**
 * Name		:	latestLogin
 * Author	:	Kony
 * Purpose	:	This function is used to Login user by providing credentials.
**/
function latestLogin() {

            username = frmLogin.txtBoxLogin.text;
		   password = frmLogin.txtBoxPswd.text;
		   
		   if(username === "" || username === null){
		   alert("Login Id should not be empty");
		   return;
		   }else if(password === "" || password ===null){
		   
		     alert("Password should not be empty");
		     return;
		   }
            var networkProvider = new konyNetworkProvider();
            var headers={};
            var params={};
			headers["X-Kony-App-Key"] = appKey
			headers["X-Kony-App-Secret"] = appSecret;
			headers["Accept"] = "application/json";
			headers["Content-Type"]="application/x-www-form-urlencoded";
			headers["Authorization"]=KeychainValue;
			
			  username = frmLogin.txtBoxLogin.text;
		      password = frmLogin.txtBoxPswd.text;
			var url="http://mbaastest8.konylabs.net:9089/authService/100000002/login";
            var endPointUrl = url + "?provider=" + providerName+"&$exclude=provider_token";
				params["provider"] = providerName;
				params["userid"] = username;
				params["password"] = password;
				
	        kony.print(" params are \n"+JSON.stringify(params));
			var logger = new konyLogger(); 
             kony.application.showLoadingScreen("sknLoading"," Login..",constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true,null);
			networkProvider.post(endPointUrl,params, headers,
				function(data) {
					data = kony.sdk.formatSuccessResponse(data);
					logger.log("### AuthService::login successful. Retrieved Data:: ");
					logger.log("data is ********************" + JSON.stringify(data));
				    logger.log(data);
					//kony.sdk.verifyAndCallClosure(successCallback, data);
 					var result=data;
      				kony.print("\n result:-"+JSON.stringify(result));
    				kony.print("Login success" + result.sso_token);
						var KonySSOtoken=result.sso_token;
							claimsToken=result.claims_token["value"];
					/*StoreInKeyChainObject.setItem(KonySSOtoken,"KonySSOtoken");
					KeychainValue= StoreInKeyChainObject.itemForKey("KonySSOtoken");
					kony.print("KeychainValue  is" + KeychainValue);*/
					if(kony.os.deviceInfo().name=="iPhone" || kony.os.deviceInfo().name=="iPhone Simulator"){
						StoreInKeyChainObject.setItem(KonySSOtoken,"KonySSOtoken");
						KeychainValue= StoreInKeyChainObject.itemForKey("KonySSOtoken");
						kony.print("KeychainValue  is" + KeychainValue);
					}else if(kony.os.deviceInfo().name=="android"){
					//store data in case of android.
						//storeToken(KonySSOtoken);
						alert("insertion success:");
					}
    				kony.print("User profile is  :" + result.profile["firstname"]);
					kony.print("User profile is  :" + result.profile["lastname"]);
					
					frmProfile.lblUsername.text=result.profile.firstname+" "+result.profile.lastname;
					frmProfile.lblEmail.text=result.profile.firstname+"."+result.profile.lastname+"@gmail.com";
    				frmProfile.show();
    				kony.application.dismissLoadingScreen();
				},
				function(data) {
					logger.log("### AuthService::login login failure. retrieved data:: ");
					logger.log(data);
					logger.log("### AuthService::login Calling failure callback");
					kony.application.dismissLoadingScreen();
					/*resetting all the token in case of error */
					//resetAllCurrentTokens(konyRef, _providerName);
					//failureCallback(kony.sdk.error.getAuthErrObj(data));
					var error=kony.sdk.error.getAuthErrObj(data);
					
					
					//Defining basicConf parameter for alert
				var basicConf = {message:error.message,alertType: constants.
				ALERT_TYPE_INFO,alertTitle: "Error",yesLabel:"OK",
				noLabel: "", alertHandler: handle2};
				
				//Defining pspConf parameter for alert
				var pspConf = {};
				
				//Alert definition
				var infoAlert = kony.ui.Alert(basicConf,pspConf);
				function handle2(response)
				{
				  
				}
				});
				}			    
   
   
   
   
   
function initApp2(){

}

/**
 * Name		:	logout
 * Author	:	Kony
 * Purpose	:	This function is used to Logout.
**/
function logout(){
     
	

	  	    kony.print("\n\n-----------in logout function---------------\n");
			var inputParamTable={
						httpheaders:{
						     "Authorization":claimsToken
			            	
			            	},
						postdata:""
					
		    };
		    try{
				var url="http://mbaastest8.konylabs.net:9089/authService/100000002/logout?provider=testcust232";
			   	kony.print("\nurl-->"+url);
			   	kony.print("\n ipTable-->"+JSON.stringify(inputParamTable));
			   	kony.application.showLoadingScreen("sknLoading","Logout..",constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true,null);
			   	var connHandle = kony.net.invokeServiceAsync(
		                        url,inputParamTable,asyncCallback);
			}catch(err){
		    	kony.print("\nexeption in invoking service---\n"+JSON.stringify(err));
				alert("Error"+err);
		    }
    
function asyncCallback(status, result) 
	{
    	kony.print("\n------status------>"+status);
    	kony.print("\n result**********************"+JSON.stringify(result));
    	if(status==400 && result["httpresponse"]!=undefined)
    	{
    			if(result["httpresponse"]["responsecode"]==400){
    				kony.print("\nError in Directlogin:-\n"+ JSON.stringify(result));
    				
    				
    				return;
    			}else if(result["httpresponse"]["responsecode"]==200){
    				kony.print("\n result:-"+JSON.stringify(result));
    				
    				frmLogin.show();
    	}
    	else{
    	       //Defining basicConf parameter for alert
				var basicConf = {message: "your login session has expired.",alertType: constants.
				ALERT_TYPE_INFO,alertTitle: "Session Expired ",yesLabel:"OK",
				noLabel: "", alertHandler: handle2};
				
				//Defining pspConf parameter for alert
				var pspConf = {};
				
				//Alert definition
				var infoAlert = kony.ui.Alert(basicConf,pspConf);
				function handle2(response)
				{
				  frmLogin.show();
				}
				
    	  
    	}
    	
    	
    	
    }
    kony.application.dismissLoadingScreen();
	}
    
    	
		   
   }
   