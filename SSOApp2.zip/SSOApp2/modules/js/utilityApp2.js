function checkSSO(){
     KeychainValue= StoreInKeyChainObject.itemForKey("KonySSOtoken");
     if(KeychainValue==null || KeychainValue==""){
        frmLogin.show();        
      }
     else{
       
        Directlogin(); 
      }

}

function powerOff(){
   
    frmLogin.show();
}

function launchParams(deepLinkParams) 
{
         
	var frmObj = ""//frmLogin;
	var deepLinkParams = params;
    //The line below displays how an application is launched: Normal, Push, URL
    kony.print("*************** deepLinkParams is: " + deepLinkParams);
    for (var key in deepLinkParams) 
    {
        kony.print("**********" + deepLinkParams[key]);
        
    }
    kony.print("*************** launch mode is: " + deepLinkParams.launchmode);
    if (deepLinkParams.launchmode == 1) 
    {
       
        frmObj = frmLogin;
        return frmObj;
    } 
    else if (deepLinkParams.launchmode == 3) 
    {
       
        //Displays the launchparams. The Launchparams table is a table with key value pairs specific to the applications needs;
        
        KeychainValue= StoreInKeyChainObject.itemForKey("KonySSOtoken");
        Directlogin();
		frmObj = frmProfile;
		return frmObj;
        
     }  else 
        {
            kony.print("*************** launchparams is nil");
            alert("launchmode == nil --> go to fromLogin");
            frmObj = frmLogin;
            return frmObj;
        }
    
    alert("go to frmLogin");
	frmObj = frmLogin;
    return frmObj; 
}