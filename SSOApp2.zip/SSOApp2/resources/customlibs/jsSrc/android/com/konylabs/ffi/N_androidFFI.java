package com.konylabs.ffi;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Vector;
import com.konylabs.api.TableLib;
import com.konylabs.vm.LuaTable;



import com.kony.sso.MainClass;
import com.kony.sso.PrimaryAppDataContentProvider;
import com.konylabs.libintf.Library;
import com.konylabs.libintf.JSLibrary;
import com.konylabs.vm.LuaError;
import com.konylabs.vm.LuaNil;


public class N_androidFFI extends JSLibrary {

 
 
	public static final String insertToken = "insertToken";
 
 
	public static final String getLoginToken = "getLoginToken";
 
	String[] methods = { insertToken, getLoginToken };


 Library libs[] = null;
 public Library[] getClasses() {
 libs = new Library[0];
 return libs;
 }



	public N_androidFFI(){
	}

	public Object[] execute(int index, Object[] params) {
		// TODO Auto-generated method stub
		Object[] ret = null;
 try {
		int paramLen = params.length;
 int inc = 1;
		switch (index) {
 		case 0:
 if (paramLen != 1){ return new Object[] {new Double(100),"Invalid Params"}; }
 java.lang.String loginToken0 = null;
 if(params[0] != null && params[0] != LuaNil.nil) {
 loginToken0 = (java.lang.String)params[0];
 }
 ret = this.insertToken( loginToken0 );
 
 			break;
 		case 1:
 if (paramLen != 0){ return new Object[] {new Double(100),"Invalid Params"}; }
 ret = this.getLoginToken( );
 
 			break;
 		default:
			break;
		}
 }catch (Exception e){
			ret = new Object[]{e.getMessage(), new Double(101), e.getMessage()};
		}
		return ret;
	}

	public String[] getMethods() {
		// TODO Auto-generated method stub
		return methods;
	}
	public String getNameSpace() {
		// TODO Auto-generated method stub
		return "androidFFI";
	}


	/*
	 * return should be status(0 and !0),address
	 */
 
 
 	public final Object[] insertToken( java.lang.String inputKey0 ){
 
		Object[] ret = null;
 Boolean val = new Boolean(com.kony.sso.MainClass.insertData( inputKey0
 ));
 
 			ret = new Object[]{val, new Double(0)};
 		return ret;
	}
 
 
 	public final Object[] getLoginToken( ){
 
		Object[] ret = null;
 java.lang.String val = com.kony.sso.PrimaryAppDataContentProvider.getToken( );
 
 			ret = new Object[]{val, new Double(0)};
 		return ret;
	}
 
};
