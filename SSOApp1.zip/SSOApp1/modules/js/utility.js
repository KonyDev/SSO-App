


function openSSOapp2(){

kony.application.openURL("ssoApp2://com.kone.sso2?kParam=frmProfile");

}



function openSSOapp3(){

kony.application.openURL("ssoApp3://com.kone.sso3?kParam=frmProfile");

}
// function to check either ssotoken is available on keychain or not.

function checkSSO(){
     KeychainValue= StoreInKeyChainObject.itemForKey("KonySSOtoken");
     if(KeychainValue==null || KeychainValue==""){
        frmLogin.show();        
      }
     else{
       
        Directlogin(); 
      }

}

