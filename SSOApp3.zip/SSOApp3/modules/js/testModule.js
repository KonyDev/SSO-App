//Invokes function 'getLoginToken'

function getData(){
var returnedValue = androidFFI.getLoginToken();
alert(returnedValue);
}
function insertInto(){
//Invokes function 'insertToken'

var returnedValue = androidFFI.insertToken(
		 "Dharmendra");
		alert("insert:-"+returnedValue);
	}
//Function to store token for android.	
function storeToken(token){
//Invokes function 'insertToken'
	kony.print("Storing token:-"+token);
	var returnedValue = androidFFI.insertToken(token);
	//alert("insert:-"+returnedValue);
}
//Function to get token for android.
function getToken(){
	var returnedValue = androidFFI.getLoginToken();
	kony.print("fetched token:-"+returnedValue);
	return returnedValue;
//alert(returnedValue);
}